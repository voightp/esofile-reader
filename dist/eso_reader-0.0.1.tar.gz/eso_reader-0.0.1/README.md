# eso_reader
A package to process E+ ouput Eso files.
